function setup() {
  createCanvas(random(500,2000), random(500,2000));
  
  let gutterWidth;
  let a = random(0, 200); // margin width
  let numColumns = floor(random(2,16));
  let numRows = floor(random(2,16));
  
// creating margins
  noStroke();
  fill(150, 70)
  //top
  rect(0, 0, width, a); 
  //left
  rect(0, 0, a, height);
  //right
  rect(width - a, 0, a, height); 
  //bottom
  rect(0, height - a, width, a); 
  
  let x = 0;
  let y = 0;
  let z = random(2, 10); // gutter width divided by 2
  
  gutterWidth = z * 2
  
  translate(-z, -z);

// Columns and gutters
  for (let i = 0; i < numColumns; i++) {
    line(x - z, 0, x - z, height+z);
    line(x + z, 0, x + z, height+z); 
    stroke(0,157,244);
    x += (width - gutterWidth * (numColumns - 1)) / numColumns + gutterWidth;
  }

// Rows and gutters
  for (let i = 0; i < numRows; i++) {
    line(0, y - z, width+z, y - z);
    line(0, y + z, width+z, y + z); 
    stroke(255, 112, 167);
    y += (height - gutterWidth * (numRows - 1)) / numRows + gutterWidth;
  }
}

// 📸 Save a png of our canvas whenever we press the key 's'
function keyTyped() {
  if (key == 's') {
    saveCanvas('photo', 'png');
  }
}

